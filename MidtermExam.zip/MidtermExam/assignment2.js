function Reveal(){

  if(onclick){

   

for(let i = 0; i=5; i++ ){

  document.getElementById("reveal").innerHTML = "revealed"

}
  }
    
}
///using a loop to tell how many clicks have been made??
//another if statment to find when i is on 5th click to change text??
