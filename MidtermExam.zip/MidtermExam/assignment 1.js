let myarray = ["Cirro", "Cumulo","Nimbo", " strato"]


for(let i = 0; i<4;i++){

document.getElementById("Loopy").innerHTML += myarray[i] + " "+ "and" + "<br />"
}
